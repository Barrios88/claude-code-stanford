---
name: fsds-panel
description: Use when the user asks to build a firm-year panel or a financial ratio from SEC Financial Statement Data Sets (FSDS), mentions sub.txt and num.txt, names an XBRL tag such as Assets or ResearchAndDevelopmentExpense, or asks for a median, share or trend of an accounting variable by fiscal year or industry (SIC) from 10-K filings. <TODO: add two or three phrases you would actually type, e.g. "cash to assets by year", "R&D intensity by industry".>
---

<!--
SKILL.md skeleton for Lab 2a. Save this file as
  ~/stanford_lab/.claude/skills/fsds-panel/SKILL.md
(project scope: it travels with the repo, and a coauthor who clones it gets it).

The frontmatter above must stay on line 1. Claude Code reads it only when the
opening --- is the file's first line.

The description is a trigger condition, not a title. "FSDS tool" is valid
YAML and the skill will rarely fire, because nothing in it matches what a
real request says. Write the phrases a request would contain. Test: if you
typed a natural request in a fresh session without naming the skill, would
this description match it?

Fill in the TODOs, delete both comment blocks, then test-fire (bottom).
-->

## What this skill does

Builds a filer-year panel of one or more XBRL tags from local FSDS quarterly files, computes a ratio, aggregates it, and leaves a figure, a table and a paper trail on disk.

## Inputs (ask for any that are missing; do not guess)

- FSDS quarters and where they live (default: `fsds/<quarter>/`, already unzipped; never download or edit them).
- Numerator tag and denominator tag, each with its `qtrs` (0 for balance-sheet stocks, 4 for flows).
- Fallback tags, if any, and what a missing tag means (missing, never zero, unless the user says otherwise).
- Grouping: fiscal year only, or SIC2 (or SIC1) by fiscal year, and any industries to exclude.
- Output file names for the figure and the table.

## Steps

1. Read `sub.txt` for each quarter. Keep `form = 10-K`. Print the 10-K count and the `fy` distribution for each quarter.
2. Read `num.txt` one quarter at a time. Keep only the needed tags and the columns `adsh, tag, version, ddate, qtrs, uom, segments, coreg, value`.
3. Keep consolidated parent rows only: `segments` and `coreg` blank, `uom = USD`. Print rows before and after.
4. Join to `sub.txt` on `adsh`. Print counts before and after, and any unmatched `adsh`.
5. Keep `ddate == period` and the right `qtrs` per tag. Check for duplicate `(adsh, tag, ddate, qtrs)` rows and stop to ask about a tie-break if any remain.
6. Before computing anything, write `DATA_PROFILE.md`: what one row is, a uniqueness test (rows and distinct keys), tag coverage per quarter, and the rule for prior-year duplicates and `10-K/A`.
7. <TODO: the measure step from your Lab 1 pipeline, including the tag decision you made and why.>
8. Plot the raw firm-level ratio by fiscal year, then compute the <TODO: median> by <TODO: grouping>, with the number of filers behind each cell.
9. Save the figure and table under the names given, append to `DECISIONS.md` and `LOG.md`, and print an attrition table.
10. End by reporting which firm-year the user should check by hand against its 10-K, and which line of which statement to read.

## Output structure

- <TODO: figure .png> and <TODO: table .csv>
- `DATA_PROFILE.md`, `DECISIONS.md`, `LOG.md`, attrition table
- Named scripts for every stage, rerunnable from the README

## Resources

- <TODO: point to your Lab 1 scripts if the skill should reuse them, e.g. `scripts/clean_join.py`. Delete this section if the skill is self-contained.>

<!--
Test-fire checklist (delete before you call it done):
- [ ] Start a NEW session in ~/stanford_lab/ (exit, then run claude again).
- [ ] Type a natural request that does not name the skill and does not say
      "fsds-panel", e.g. "Give me median total liabilities over assets by
      fiscal year from the 10-Ks in these files."
- [ ] Confirm the transcript shows Claude loading the fsds-panel skill. If you
      see it reading your old Lab 1 scripts instead, it did not fire. Rewrite
      the description as a trigger and try again.
- [ ] Typing /fsds-panel runs it on purpose, but that does not test the
      description.
- [ ] Run it on a measure you did NOT build in Lab 1 and check it produces
      the output structure above.
-->
