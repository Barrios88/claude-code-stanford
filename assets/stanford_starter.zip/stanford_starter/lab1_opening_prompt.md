# Lab 1 opening prompt: empty folder to verified figure (50 minutes)

This is the six-part prompt from the demo, adapted for the lab. Pick one tier, fill in every `<TODO>`, and paste the whole thing as your first message in `~/stanford_lab/`, before you ask for any code. DATA, JOIN and PAPER TRAIL are already written. Leave PAPER TRAIL exactly as it is, even if you are short on time. That part produces `DATA_PROFILE.md`, `DECISIONS.md` and `LOG.md`.

Before you paste: `CLAUDE.md` is saved in `~/stanford_lab/`, `fsds/` holds the three unzipped quarters, and `git init` has been run. Commit after each stage that works.

## Pick a tier

**Base: cash holdings.** Cash and cash equivalents over total assets, median by fiscal year. Tag facts from the class data (share of 10-Ks reporting the tag for the current period, consolidated rows):

| Tag (qtrs = 0) | 2016q1 | 2020q1 | 2024q1 |
|---|---|---|---|
| `Assets` | 98.4% | 98.7% | 99.4% |
| `CashAndCashEquivalentsAtCarryingValue` | 91.3% | 85.1% | 80.5% |
| `CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents` | 0% | 57.5% | 79.3% |

The cash tag's coverage falls over time because the 2018 restricted-cash standard (ASU 2016-18) led many filers to report cash including restricted cash, under the third tag, and some stopped reporting the first. Decide in `DECISIONS.md` whether a filer missing the first tag drops out or falls back to the third, and report the median both ways. Also decide whether to keep banks and other financial firms (SIC 6000–6799, a bit over a quarter of these filers), for whom cash over assets means something different.

**Standard: R&D intensity.** R&D expense over total assets, median by two-digit SIC for the five largest SIC2 groups, by fiscal year. Pick the five groups by the number of filers that report the R&D tag, pooled across the three years, and print those counts. Only 26% to 33% of 10-Ks report `ResearchAndDevelopmentExpense` (qtrs = 4), and almost none report an explicit zero (3 to 6 filings a year). A filer with no R&D row is a filer with a missing tag, not a filer with zero R&D, so do not fill missing with zero. Some large R&D spenders report under `ResearchAndDevelopmentExpenseExcludingAcquiredInProcessCost` instead (about 2% of 10-Ks). Decide whether to fall back to it, and check at least one large pharmaceutical firm against its 10-K income statement.

**Stretch: your own question.** Use the one-sentence research question you brought. It has to be answerable, at least in part, from face-statement numbers in these three quarters. Name the tags, check their coverage in `DATA_PROFILE.md` before you build anything, and use the same JOIN, PAPER TRAIL and verify checklist as everyone else.

---

## The prompt

**DATA:** The SEC Financial Statement Data Sets for three quarters are already downloaded and unzipped in `fsds/2016q1/`, `fsds/2020q1/` and `fsds/2024q1/`. Do not download anything and do not modify these files. These quarters hold mostly 10-Ks for fiscal years 2015, 2019 and 2023. From each quarter use two tab-delimited files: `sub.txt` (filing metadata: `adsh`, `cik`, `name`, `sic`, `form`, `fy`, `period`) and `num.txt` (tagged values: `adsh`, `tag`, `version`, `ddate`, `qtrs`, `uom`, `segments`, `coreg`, `value`). Read `num.txt` one quarter at a time and keep only the tags and columns you need before combining quarters.

**JOIN:** Merge `sub.txt` and `num.txt` on `adsh`, the filing's accession number. State the row count in each file before the join and the row count after, and flag any `adsh` in `num.txt` with no match in `sub.txt`. Keep only consolidated, parent-registrant values: rows where `segments` and `coreg` are blank and `uom` is `USD`. Report the row count before and after this filter. Keep only values for the filing's own period (`ddate` equal to `period` in `sub.txt`), so the prior-year comparatives in each 10-K drop out. Then check for remaining duplicate `(adsh, tag, ddate, qtrs)` rows and document a tie-break rule if you find any.

**MEASURE:** <TODO: name the measure>, defined as <TODO: numerator> divided by <TODO: denominator> for each filer and fiscal year. Use the XBRL tag `<TODO>` for the numerator and `<TODO>` for the denominator. Keep `qtrs = 0` for balance-sheet tags (a snapshot) and `qtrs = 4` for flow tags (a full fiscal year), and say which applies to each tag. Restrict to `form = 10-K` and `Assets > 0`. <TODO: the tier's decision, e.g. "If a filer lacks the cash tag, fall back to ... and flag it" or "Treat a missing R&D tag as missing, never as zero">.

**AGGREGATION:** Compute the median by <TODO: fiscal year (`fy` in `sub.txt`) / two-digit SIC (`sic2`, the first two digits of `sic`) and fiscal year> across the three quarters. Report the number of filers behind every median.

**OUTPUT:** One <TODO: line / bar> figure formatted for a working-paper draft (white background, labeled axes, a legend if there is more than one series, no default plotting-library styling), saved as `<TODO: filename.png>`. Save the aggregated table behind it as `<TODO: filename.csv>`.

**PAPER TRAIL:** Write every stage as a named script. No output should exist only as a chat reply. Keep a `DECISIONS.md` recording every methodological choice as it's made: which tag was chosen when more than one was available, how duplicate rows were handled, any filter applied and why. Keep a `LOG.md` with a timestamped line for every major step. Print an attrition row (n before, n after, reason) every time the sample size changes. Before computing any measure or drawing any figure, write a `DATA_PROFILE.md`: what one row of each table is, a uniqueness test on that row (report the row count and the count of distinct key combinations), the share of 10-K filings in each quarter that report each tag you use, and the rule for prior-year duplicates and `10-K/A` amendments.

---

## Then work in this order

1. Send the prompt. Read `DATA_PROFILE.md` as soon as it exists, before any measure is computed. Do the row counts and tag coverage look like the numbers above?
2. Ask for a plot of the raw firm-level ratio by fiscal year, before any median.
3. Write your two named checks (one benchmark, one plausibility) into the README before the figure exists.
4. Let the figure render. Refine it in at most three rounds, one problem per round.
5. Check one firm-year value against that firm's actual 10-K on EDGAR. Pick a firm with a December year end, because these are first-quarter files: Apple (September year end) files its 10-K in the fall, so it is not in them.
6. Ask Claude to write the README last. Commit.

If Claude heads the wrong way, press Esc, restate the step plainly, and let it start again. Don't argue with it in the chat.
