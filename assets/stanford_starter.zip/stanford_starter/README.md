# Starter pack: Claude Code for Empirical Research

John Barrios · Yale School of Management · Prepared for Stanford PhD students

This pack has everything you need before and during the session. It contains no data. The SEC data are public, and you download them yourself before class.

## What each file is for, in the order you use it

**Before class (due by noon on Sunday, November 1)**

1. `setup_check_prompt.md`. The smoke test. In an empty folder, start `claude` and paste the prompt. It writes `setup_check.txt` with your tool versions, one number from Apple's 10-K, and the date. You then check that number against the filing yourself.
2. `download_fsds.sh`. Downloads the three SEC Financial Statement Data Sets quarters we use in class (2016q1, 2020q1, 2024q1) and unzips each into `fsds/<quarter>/`. About 316 MB to download and about 1.6 GB on disk once unzipped. Run it before class so the room's wifi can't hold you up.

**In class, Lab 1 (50 minutes)**

3. `CLAUDE.md.template`. A short project memory. Fill in the three blanks and save it as `CLAUDE.md` in your lab folder before you send any prompt.
4. `lab1_opening_prompt.md`. The six-part opening prompt (DATA, JOIN, MEASURE, AGGREGATION, OUTPUT, PAPER TRAIL) with three tiers. Pick a tier, fill in the blanks, paste it.
5. `lab1_verify_checklist.md`. Work through it before you call Lab 1 done.

**In class, Lab 2 (55 minutes)**

6. `SKILL_skeleton.md`. Turns your Lab 1 pipeline into `.claude/skills/fsds-panel/SKILL.md`, which you test in a fresh session.
7. `lab2_verification_drills.md`. Three drills on your own repo: the two-check credential audit, a clean-room referee, and one deny rule.

**End of class**

8. `exit_ticket.md`. Four short written answers, done in the last minutes of class.

## Folder layout we assume

```
~/setup_check/          empty folder for the smoke test
~/stanford_lab/         your lab project (a git repo)
    fsds/2016q1/        sub.txt, num.txt, pre.txt, tag.txt, readme.htm
    fsds/2020q1/
    fsds/2024q1/
    CLAUDE.md
    .gitignore          contains the line: fsds/
~/stanford_starter/     this pack, unzipped (keep it outside the lab folder)
```

To set up the lab folder and the data in one go:

```bash
mkdir -p ~/stanford_lab && cd ~/stanford_lab
git init
echo "fsds/" > .gitignore          # never commit 1.6 GB of raw data
export SEC_UA="Your Name your.email@stanford.edu"
bash ~/stanford_starter/download_fsds.sh
```

Keep the starter pack outside `~/stanford_lab/`. Copy a file in only when a step tells you to. An agent that opens a folder full of templates and instructions will read them, and you want it to see your project and nothing else.

## Where to go after class

The full six-module course, with videos, slides and labs for everything we only touch on today: https://johnmbarrios.com/claude-code-accounting/ (access code `Barrios_AI2026`). Its Module 4 covers connecting Claude Code to WRDS on your own account.
