# Lab 2b: verification drills (25 minutes)

Three drills, all on your own `~/stanford_lab/` repo. Paste the output of each into `VERIFY_NOTES.md` in the repo. Writing "it's clean" is not the deliverable. The pasted output is.

---

## Drill 1: the two-check credential audit (10 min)

Run both from the root of `~/stanford_lab/`. Both should come back clean.

### Check 1: has a credential file ever been committed?

```bash
git log --all --full-history --oneline -- '*.env' '*.env.*' '.mcp.json'
```

**Expected output:** nothing (an empty result).

This looks for a `.env` file, or a variant such as `.env.local`, in any folder and at any point in the history, plus a project-level `.mcp.json` (which holds credentials if you ever registered an MCP server with project scope). If it returns even one commit, a credential file was committed at some point. Deleting the file now does **not** remove it from history: anyone who clones the repo, including a coauthor, a referee running a replication package, or a stranger on GitHub, can still find it in an old commit with `git show <commit>:<path>`.

### Check 2: does your actual key appear anywhere?

There is no WRDS password today, so this check runs on any API key or token you have actually used (an Anthropic API key, a GitHub token, a data-vendor key). Type the first line, paste the key when the cursor waits (it won't echo), and press Enter:

```bash
read -s SECRET
: "${SECRET:?paste your key first}"
git log --all --oneline -S"$SECRET"
git grep -l -F --untracked -e "$SECRET"
```

**Expected output:** nothing.

- Line 1 reads your key into the shell without showing it on screen or saving it in your shell history.
- Line 2 stops with an error if the key didn't load, so an empty search can't pass by accident.
- Line 3 lists every commit that ever added or removed the key, including in a script you have since deleted.
- Line 4 lists files git would pick up that contain it now. It skips gitignored files.

Both searches print commit IDs or file names, never the key. They look for the key itself, not a variable name such as `API_KEY`, so a script that reads the key from the environment (the right way) passes, and a script with the key typed into it fails. Do not use a plain `grep -r "API_KEY" .` instead: it flags correct code and misses a key that was committed and later deleted.

Repeat Check 2 for every other secret the project touches. When you are done, run `unset SECRET`.

**If you have never used an API key** (a Pro or Max subscription needs none), prove to yourself that the check works. Practice on a clone, never on your real repo:

```bash
git clone -q ~/stanford_lab ~/audit_practice && cd ~/audit_practice
echo 'key = "sk-FAKE-practice-0000"' > leak.py && git add leak.py && git commit -qm "oops"
git rm -q leak.py && git commit -qm "remove it"
SECRET="sk-FAKE-practice-0000"
git log --all --oneline -S"$SECRET"     # shows both commits: deleting didn't erase it
cd ~ && rm -rf ~/audit_practice && unset SECRET
```

### Also confirm: raw data never committed

```bash
git log --all --full-history --oneline -- 'fsds/*' '*.zip' '*.parquet' '*.dta'
```

**Expected output:** nothing. If anything prints, your `.gitignore` was missing `fsds/` when you committed.

### If either check finds something

1. **Treat the credential as compromised right away.** Do not assume it is fine because no one saw it. Assume any credential that has ever been committed to a git repository is exposed, even in a private repo and even if you never pushed it anywhere.
2. **Revoke and rotate first, clean up second.** Regenerate the API key before you touch the repository. The order matters. If you clean the repo first and rotate later, the exposed credential stays valid while you work.
3. **Remove it from history, not just the current version.** Deleting the current copy is not enough while the secret is still reachable in `git log` history. A history rewrite with `git filter-repo` or BFG removes it. If the project is small and early, starting a fresh repository is simpler.
4. **Confirm the fix** by re-running both checks above and getting a clean result before you consider the audit passed.

---

## Drill 2: a clean-room referee (10 min)

A session that watched you build the pipeline has heard all your reasons and tends to accept them. A referee hasn't. So give the review its own room: a folder that holds only what a reader of your paper would see, and a deny rule that keeps the session from editing it.

1. In `~/stanford_lab/`, write `summary.md` yourself (5 minutes, no agent): the figure caption, a short paragraph describing how the sample was built (files, filters, tags, the tag decision), and the attrition table. Leave out `DECISIONS.md` and your scripts. A referee gets the paper, not your notes.
2. Build the room and start a fresh session in it:

   ```bash
   mkdir -p ~/referee_room/paper ~/referee_room/.claude
   cp ~/stanford_lab/summary.md ~/stanford_lab/*.png ~/referee_room/paper/
   echo '{"permissions":{"deny":["Edit(./paper/**)"]}}' > ~/referee_room/.claude/settings.json
   cd ~/referee_room && claude
   ```

3. Paste:

   ```
   You are refereeing a short empirical exhibit for an accounting journal. You
   have only what is in paper/. Do not edit any file. Read the caption, the
   sample description and the attrition table, and look at the figure. Write
   the three most serious objections to review/referee.md, most serious first.
   For each, say what claim it undermines and what evidence would answer it.
   Check whether the stated filters can produce the N in the attrition table.
   Aim the criticism at the exhibit, not the author.
   ```

4. Read `review/referee.md`. In `VERIFY_NOTES.md`, write one objection it raised that you had stopped seeing, and answer one objection in writing in the report file, not in the chat (in the chat, the model tends to concede).

The room is cleaner than a session inside your project, not perfectly clean: your personal `~/.claude/CLAUDE.md` still loads, so keep project details out of it.

---

## Drill 3: one deny rule, tested (5 min)

`CLAUDE.md` says "never edit the raw data." That is a request, which the model usually follows. A deny rule in `.claude/settings.json` is enforced by Claude Code in every permission mode.

1. Create `~/stanford_lab/.claude/settings.json` (merge by hand if the file already exists):

   ```json
   {
     "permissions": {
       "deny": [
         "Edit(./fsds/**)",
         "Read(./.env)",
         "Read(./.env.*)"
       ]
     }
   }
   ```

2. Record a fingerprint of one raw file: `shasum fsds/2024q1/readme.htm`
3. Start a **new** session in `~/stanford_lab/`. Run `/permissions` and confirm the three rules are listed.
4. Ask: *"Append the line 'test' to fsds/2024q1/readme.htm with your file edit tool. Then try a shell command, echo test >> fsds/2024q1/readme.htm. Quote any error you get."* Both attempts should be refused.
5. Run `shasum fsds/2024q1/readme.htm` again. It must match step 2. Paste the refusal text and both fingerprints into `VERIFY_NOTES.md`.
6. Commit `.claude/settings.json` so every coauthor who opens the repo works under the same rule.

Know the limit. The rule matches Claude's file tools and shell commands that name the path. A Python script that opens the file itself is not stopped by it. Only an operating-system sandbox (`/sandbox`, or a container) enforces a boundary that holds however the command is phrased. The full course's Module 5 covers both.
