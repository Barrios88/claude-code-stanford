#!/usr/bin/env bash
# download_fsds.sh: fetch the three SEC Financial Statement Data Sets quarters
# used in class and unzip each into fsds/<quarter>/.
#
# Usage, from the folder where you want the data:
#   export SEC_UA="Your Name your.email@university.edu"
#   bash download_fsds.sh
#
# SEC refuses requests that don't identify the requester (you get
# "403 Forbidden"), so SEC_UA must be your real name and email.
# Total download is about 316 MB zipped and about 1.6 GB unzipped.
# The script skips any quarter that is already unzipped, so it is safe to rerun.

set -euo pipefail

: "${SEC_UA:?Set SEC_UA first, e.g. export SEC_UA=\"Jane Doe jdoe@stanford.edu\"}"

QUARTERS="2016q1 2020q1 2024q1"
BASE="https://www.sec.gov/files/dera/data/financial-statement-data-sets"

command -v unzip >/dev/null || { echo "unzip is not installed. On Ubuntu/WSL run: sudo apt install -y unzip"; exit 1; }

mkdir -p fsds
for q in $QUARTERS; do
  if [ -s "fsds/$q/num.txt" ] && [ -s "fsds/$q/sub.txt" ]; then
    echo "$q: already unzipped in fsds/$q/, skipping"
    continue
  fi
  echo "$q: downloading..."
  curl -fL --retry 3 -A "$SEC_UA" -o "fsds/$q.zip" "$BASE/$q.zip"
  mkdir -p "fsds/$q"
  unzip -oq "fsds/$q.zip" -d "fsds/$q"
  rm "fsds/$q.zip"
  echo "$q: done ($(wc -l < "fsds/$q/sub.txt") lines in sub.txt)"
  sleep 1   # stay well under SEC's 10 requests per second
done

echo
echo "Check: each folder should hold sub.txt, num.txt, pre.txt, tag.txt and readme.htm"
ls -lh fsds/*/sub.txt fsds/*/num.txt
