# Smoke test (due 48 hours before class)

This takes about 15 minutes once Claude Code is installed and signed in. It checks three things at once: that Claude Code can write and run code on your machine, that your Python has pandas and matplotlib, and that you can reach SEC servers with a proper User-Agent.

## Steps

1. Open a terminal (Windows: your Ubuntu/WSL window).
2. Make an empty folder and start Claude Code in it:
   ```bash
   mkdir -p ~/setup_check && cd ~/setup_check && claude
   ```
3. Paste the prompt below. Replace the one TODO with your real name and email first.
4. Approve the actions Claude asks about. Read each one before you approve it.
5. Do the hand check at the bottom. This is the step that matters.

## The prompt

```
Write a Python script named setup_check.py in this folder and run it. It should
write a plain-text file named setup_check.txt with one item per line:

1. Today's date.
2. The output of: claude --version, python3 --version, git --version.
3. The installed versions of pandas and matplotlib (import each and print
   __version__). If an import fails, write the error on that line and keep going.
4. Apple Inc.'s total assets from one specific filing: the Form 10-K for the
   fiscal year ended September 27, 2025, accession number 0000320193-25-000079.
   Get it from the SEC XBRL API at
   https://data.sec.gov/api/xbrl/companyconcept/CIK0000320193/us-gaap/Assets.json
   Send the header "User-Agent: <TODO: Your Name your.email@stanford.edu>" on the
   request. The JSON lists the same filing more than once, because a 10-K also
   reports the prior year's balance sheet. Keep only the entry whose accn is
   0000320193-25-000079 AND whose end date is 2025-09-27. Write the value in
   millions of US dollars, with the accession number and end date beside it.
5. A last line that reads: "Checked against the 10-K by hand: ____"

Do not hardcode the Apple number. Print the finished setup_check.txt when done.
```

## The hand check (do not skip)

Claude got the number from an API. Now check it against the filing itself, a source Claude did not touch:

1. Open the 10-K in your browser:
   https://www.sec.gov/Archives/edgar/data/320193/000032019325000079/aapl-20250927.htm
2. Find **CONSOLIDATED BALANCE SHEETS** (search the page for that phrase). Figures are in millions.
3. Read the **Total assets** line in the **September 27, 2025** column. The column next to it is the prior year. Don't use it.
4. If the two numbers match, open `setup_check.txt` and fill in the last line yourself: "yes, $___ million, balance sheet, Sept 27 2025 column". If they don't match, write down both numbers and say which column you read.

Bring `setup_check.txt` to class. If any line fails and you can't fix it, email me at john.m.barrios@yale.edu at least 48 hours before class with the file and the error message.

## If something breaks

- **`claude` not found:** open a new terminal window. If that doesn't fix it, see Anthropic's [setup guide](https://code.claude.com/docs/en/setup) and run `claude doctor`.
- **It asks you to log in and fails:** Claude Code needs a Pro or Max subscription or an API key. A free Claude.ai account does not work.
- **pandas or matplotlib missing:** `pip3 install pandas matplotlib` (on newer Ubuntu/WSL add `--break-system-packages`), or ask Claude to install them and explain each command first.
- **`403 Forbidden` from the SEC:** the request went out without a real name and email in the User-Agent. Fix the TODO and rerun.
