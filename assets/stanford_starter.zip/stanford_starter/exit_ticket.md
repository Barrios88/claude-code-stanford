# Exit ticket

Name: ______________________________  Tier you ran in Lab 1: Base / Standard / Stretch

Write by hand or in your own words. One or two sentences per question is enough. Be specific.

**1. One thing that broke today, and how you found out.**
(An install step, a tag, a join, a figure, a skill that didn't fire, a check that failed. Say what you saw that told you.)

&nbsp;

&nbsp;

**2. One thing you will verify next time before you trust a similar result.**
(Name the check and the source you would check against.)

&nbsp;

&nbsp;

**3. One research task you will delegate to an agent from now on.**
(Name a real task from your own work, not a category.)

&nbsp;

&nbsp;

**4. One research task you will not delegate, and why.**

&nbsp;

&nbsp;

**Optional:** the one-sentence research question you brought. Did today change how you would build it?

&nbsp;

&nbsp;
