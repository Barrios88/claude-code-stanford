# Lab 1 verify checklist

Self-graded, pass/fail. Work through every line before you call Lab 1 done. I spot-check a few in the room.

- [ ] `DATA_PROFILE.md` was written before the first figure. It states what one row is, a uniqueness test with both counts (rows and distinct keys), tag coverage for each quarter, and the rule for prior-year duplicates and `10-K/A` amendments.

- [ ] `sub` and `num` joined on `adsh`, with row counts before and after the join.

- [ ] Consolidated filter applied (`segments` and `coreg` blank, `uom` = USD), with row counts before and after. No duplicate `(adsh, tag, ddate, qtrs)` rows remain, or the tie-break is in `DECISIONS.md`.

- [ ] `form` = 10-K only, and the right `qtrs` for each tag: 0 for balance-sheet stocks, 4 for flows.

- [ ] Attrition table present, and every change in sample size is explained in `DECISIONS.md`.

- [ ] The tier's tag decision is in `DECISIONS.md` (cash fallback and financials for Base; missing-is-not-zero and the fallback tag for Standard; coverage of your own tags for Stretch).

- [ ] Raw firm-level series plotted before aggregating.

- [ ] Two sanity checks written down, each with a source.

      Benchmark comparison: ____________________________________________

      Source: __________________________________________________________

      Plausibility check: ______________________________________________

      Source: __________________________________________________________

- [ ] One firm-year value checked against the actual 10-K on EDGAR.

      Firm, fiscal year, line item: ______________________________________

      Your pipeline's value: __________  The 10-K's value: __________

      Which statement and column you read: ______________________________

- [ ] The figure comes from a named script. No result exists only in the chat.

- [ ] The README says how to rerun the pipeline from `fsds/` to the figure, and at least one commit exists.

## If a box is unchecked

Leave it unchecked and write in the README what is blocking it.
